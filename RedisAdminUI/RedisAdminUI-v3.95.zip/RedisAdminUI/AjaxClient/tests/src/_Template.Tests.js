YAHOO.namespace("ajaxstack");
YAHOO.ajaxstack._TemplateTests = new YAHOO.tool.TestCase({

    name: "_Template Tests",

	//--------------------------------------------- 
	// Setup and tear down 
	//---------------------------------------------

	setUp: function()
	{
	},

	tearDown: function()
	{
	},

	//--------------------------------------------- 
	// Tests 
	//---------------------------------------------

	test_Template: function()
	{
	}

});

